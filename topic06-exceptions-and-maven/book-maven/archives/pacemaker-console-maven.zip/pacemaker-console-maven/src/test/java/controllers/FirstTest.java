package controllers;

//source:  https://github.com/junit-team/junit5-samples

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class) 
class FirstTest {

	@Test
	@DisplayName("My 1st JUnit 5 test!")
	void myFirstTest(TestInfo testInfo) {
		assertEquals(2, 1 + 1, "1 + 1 should equal 2");
		assertEquals("My 1st JUnit 5 test!", testInfo.getDisplayName(), () -> "TestInfo is injected correctly");
	}

	@Test
	@DisplayName("Another first test!")
	void myFirstTest2(TestInfo testInfo) {
		assertEquals(2, 2);
	}

}